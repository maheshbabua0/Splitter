package com.example.expense;

import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
public class ExpenseController {

    @PostMapping("/api/split")
    public List<String> splitExpenses(@RequestBody List<Roommate> roommates) {
        return ExpenseService.calculateSplit(roommates);
    }
}