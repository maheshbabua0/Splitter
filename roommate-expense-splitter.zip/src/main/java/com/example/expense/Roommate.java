package com.example.expense;

public class Roommate {
    private String name;
    private double paid;

    public Roommate() {}
    public Roommate(String name, double paid) {
        this.name = name;
        this.paid = paid;
    }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public double getPaid() { return paid; }
    public void setPaid(double paid) { this.paid = paid; }
}