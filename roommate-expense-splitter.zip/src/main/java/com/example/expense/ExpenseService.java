package com.example.expense;

import java.util.*;

public class ExpenseService {
    public static List<String> calculateSplit(List<Roommate> roommates) {
        double total = roommates.stream().mapToDouble(Roommate::getPaid).sum();
        double share = total / roommates.size();

        List<String> results = new ArrayList<>();
        results.add("Total: ₹" + total);
        results.add("Each should pay: ₹" + share);

        for (Roommate r : roommates) {
            double balance = r.getPaid() - share;
            String status = (balance >= 0) ? "should receive" : "owes";
            results.add(r.getName() + " " + status + " ₹" + String.format("%.2f", Math.abs(balance)));
        }

        return results;
    }
}